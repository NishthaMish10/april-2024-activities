package com.dao.Loanapplication;


import org.springframework.data.jpa.repository.JpaRepository;
import com.example.Loanapplication.*;

public interface CustomerDao extends JpaRepository<Customer, Integer> {

    boolean existsByEmailIdAndPassword(String emailId, String password);
}

