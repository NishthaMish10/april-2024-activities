package com.service.Loanapplication;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.Loanapplication.*;
import com.dao.Loanapplication.*;

@Service
public class CustomerServiceImpl implements CustomerServic {



@Autowired
private CustomerDao customerDao;

@Override
public Customer store(Customer customer) {
    return customerDao.save(customer);
}

@Override
public boolean existsByEmailIdAndPassword(String emailId, String password) {
    return customerDao.existsByEmailIdAndPassword(emailId, password);
    
}
}

