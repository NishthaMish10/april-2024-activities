package com.service.Loanapplication;

import com.example.Loanapplication.*;

public interface CustomerServic {
    
    public Customer store(Customer customer);

    boolean existsByEmailIdAndPassword(String emailId, String password);
}