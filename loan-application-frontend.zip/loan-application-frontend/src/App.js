import React from 'react';

import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';


import Login from './components/LoanOfficer/Login';
import Register from './components/customer/Register';
import ViewLoans from './components/customer/ViewLoans';
import ApplyLoan from './components/customer/Applyloan';
import LoanStatus from './components/customer/LoanStatus';
import ViewApplications from './components/loanOfficer/ViewApplications'; // Corrected import path
import UpdateApplication from './components/LoanOfficer/UpdateApplication'; // Corrected import path
import ViewCreditScores from './components/loanOfficer/ViewCreditScores'; // Corrected import path


function App() {
  return (
    <Router>
      <div>
        <Switch>
          <Route path="/login" component={Login} />
          <Route path="/register" component={Register} />
          <Route path="/view-loans" component={ViewLoans} />
          <Route path="/apply-loan" component={ApplyLoan} />
          <Route path="/loan-status" component={LoanStatus} />
          <Route path="/view-applications" component={ViewApplications} />
          <Route path="/update-application" component={UpdateApplication} />
          <Route path="/view-credit-scores" component={ViewCreditScores} />
          {/* Add more routes as needed */}
          <Route exact path="/" component={Login} />
          {/* Default route */}
        </Switch>
      </div>
    </Router>
  );
}

export default App;
