import React, { useState } from 'react';
import axios from 'axios';
import './RegistrationForm.css';

const RegistrationForm = () => {
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        email: '',
        password: '',
        pan: '',
        phone: ''
    });

    const [errors, setErrors] = useState({}); // State for validation errors

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    const handleRegistration = () => {
        let errors = {};

        if (formData.firstName.trim() === '') {
            errors.firstName = 'First Name is required';
        }

        if (formData.lastName.trim() === '') {
            errors.lastName = 'Last Name is required';
        }

        if (formData.email.trim() === '') {
            errors.email = 'Email is required';
        }

        if (formData.password.trim() === '') {
            errors.password = 'Password is required';
        }

        if (formData.pan.trim() === '') {
            errors.pan = 'PAN Number is required';
        }

        if (formData.phone.trim() === '') {
            errors.phone = 'Phone Number is required';
            errors.phone = 'Phone Number is required';
        }

        if (Object.keys(errors).length === 0) {
                axios.post('', formData)
                    .then(response => {
                        
                        console.log('Registration successful:', response.data);
                        
                    })
                    .catch(error => {
                        
                        console.error('Registration error:', error);
                    });
            } else {
                setErrors(errors);
            }
        };
        
       

    return (
        <div className="form-container">
            <h2>Customer Registration</h2>
            <input type="text" name="firstName" placeholder="First Name" onChange={handleInputChange} />
            {errors.firstName && <p className="error">{errors.firstName}</p>}
            <input type="text" name="lastName" placeholder="Last Name" onChange={handleInputChange} />
            {errors.lastName && <p className="error">{errors.lastName}</p>}
            <input type="email" name="email" placeholder="Email" onChange={handleInputChange} />
            {errors.email && <p className="error">{errors.email}</p>}
            <input type="password" name="password" placeholder="Password" onChange={handleInputChange} />
            {errors.password && <p className="error">{errors.password}</p>}
            <input type="text" name="pan" placeholder="PAN Number" onChange={handleInputChange} />
            {errors.pan && <p className="error">{errors.pan}</p>}
            <input type="text" name="phone" placeholder="Phone Number" onChange={handleInputChange} />
            {errors.phone && <p className="error">{errors.phone}</p>}
            <button onClick={handleRegistration}>Register</button>
        </div>
    );
};

export default RegistrationForm;