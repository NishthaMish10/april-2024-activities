import React, { useState } from 'react';
import ApiService from '../../services/ApiService';

function ViewCreditScores() {
  const [pan, setPan] = useState('');
  const [creditScore, setCreditScore] = useState('');
  const [loading, setLoading] = useState(false);

  const fetchCreditScore = async () => {
    try {
      setLoading(true);
      // Make API call to fetch credit score
      const score = await ApiService.getCreditScore(pan);
      setCreditScore(score);
    } catch (error) {
      console.error('Error fetching credit score:', error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2>View Credit Scores</h2>
      <div>
        <label htmlFor="pan">Enter PAN:</label>
        <input type="text" id="pan" value={pan} onChange={(e) => setPan(e.target.value)} />
        <button onClick={fetchCreditScore}>Fetch Credit Score</button>
      </div>
      {loading ? (
        <p>Loading...</p>
      ) : creditScore ? (
        <p>Credit Score: {creditScore}</p>
      ) : null}
    </div>
  );
}

export default ViewCreditScores;
