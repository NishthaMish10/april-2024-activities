import React, { useState } from 'react';
import ApiService from '../../services/Apiservice';

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    try {
      const token = await ApiService.login(email, password);
      localStorage.setItem('token', token);
      // Redirect to dashboard or desired page
    } catch (error) {
      console.error('Login failed:', error.message);
      // Handle error: display error message to the user
    }
  };

  return (
    <div>
      <h2>Login</h2>
      <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
      <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
      <button onClick={handleLogin}>Login</button>
    </div>
  );
}

export default Login;
