import React, { useState } from 'react';
import ApiService from '../../services/Apiservice';

function ApplyLoanForm() {
  const [loanType, setLoanType] = useState('');
  const [amount, setAmount] = useState('');
  const [duration, setDuration] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      
      await ApiService.applyForLoan({ loanType, amount, duration });
      
    } catch (error) {
      console.error('Loan application failed:', error.message);
      
    }
  };

  return (
    <div>
      <h2>Apply for Loan</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="loanType">Loan Type:</label>
          <select id="loanType" value={loanType} onChange={(e) => setLoanType(e.target.value)}>
            <option value="">Select Loan Type</option>
            <option value="Housing Loan">Housing Loan</option>
            <option value="Educational Loan">Educational Loan</option>
            <option value="Gold Loan">Gold Loan</option>
            
          </select>
        </div>
        <div>
          <label htmlFor="amount">Loan Amount:</label>
          <input type="text" id="amount" value={amount} onChange={(e) => setAmount(e.target.value)} />
        </div>
        <div>
          <label htmlFor="duration">Loan Duration (in months):</label>
          <input type="text" id="duration" value={duration} onChange={(e) => setDuration(e.target.value)} />
        </div>
        <button type="submit">Apply</button>
      </form>
    </div>
  );
}

export default ApplyLoanForm;
