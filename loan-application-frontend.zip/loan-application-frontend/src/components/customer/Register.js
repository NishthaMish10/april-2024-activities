import React, { useState } from 'react';
import ApiService from '../../services/Apiservice';

function Register() {
  const [firstname, setFirstname] = useState('');
  const [lastname, setLastname] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [pan, setPan] = useState('');
  const [phone, setPhone] = useState('');

  const handleRegister = async () => {
    try {
      await ApiService.register({ firstname, lastname, email, password, pan, phone });
      
      
    } catch (error) {
      console.error('Registration failed:', error.message);
      
    }
  };

  return (
    <div>
      <h2>Register</h2>
      <input type="text" placeholder="First Name" value={firstname} onChange={(e) => setFirstname(e.target.value)} />
      <input type="text" placeholder="Last Name" value={lastname} onChange={(e) => setLastname(e.target.value)} />
      <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
      <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
      <input type="text" placeholder="PAN" value={pan} onChange={(e) => setPan(e.target.value)} />
      <input type="text" placeholder="Phone" value={phone} onChange={(e) => setPhone(e.target.value)} />
      <button onClick={handleRegister}>Register</button>
    </div>
  );
}

export default Register;
